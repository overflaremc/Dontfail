package me.overflare.overpvp;

import org.bukkit.plugin.java.JavaPlugin;

public final class OverPvP extends JavaPlugin {
    @Override
    public void onEnable() {
        saveDefaultConfig();
        for (String resource : new String[]{"messages.yml", "kits.yml", "arenas.yml", "ranking.yml", "tournaments.yml", "titles.yml"}) {
            saveResource(resource, false);
        }
        getLogger().info("OverPvP enabled. Made by OverFlareMC.");
    }

    @Override
    public void onDisable() {
        getLogger().info("OverPvP disabled safely.");
    }
}
