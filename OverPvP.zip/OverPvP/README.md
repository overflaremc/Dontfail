# OverPvP

**Made by OverFlareMC**

Maven/Paper foundation for the OverPvP competitive PvP plugin.

## Build in GitHub Codespaces

```bash
mvn clean package
```

Output:

```text
target/OverPvP.jar
```

The repository is intentionally modular so GitHub Copilot can continue implementing queues, matches, arenas, kits, rankings, parties, spectators, replays, history, tournaments, GUIs and storage without putting everything into one giant class.
